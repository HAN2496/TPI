from dataclasses import asdict
import json
import numpy as np
import torch
from pathlib import Path
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split

from ..experiment import BaseExperiment
from .gcf import CoPLGCF
from .rm import (RewardModel, CNNRewardModel, MoLECNNRewardModel, PreferenceTransformerRewardModel,
                 ObsOnlyRewardModel, ObsOnlyCNNRewardModel, ObsOnlyPreferenceTransformerRewardModel,
                 RMEdgeDataset, rm_collate)
from .dataset import CoPLGraphDataset
from .similarity import build_similarity
from .trainer import CoPLGCFTrainer, CoPLRMTrainer
from .visualization import (plot_test_item_bridge, plot_item_embeddings,
                            plot_user_embeddings, plot_rm_distributions, plot_wu_evolution, STYLE)
from ...evaluation import evaluate_predictions, save_metrics_txt, compute_sequential_aurocs, plot_sequential_auroc, plot_training_curves


ABL_ADAPTED = "Proposed"
ABL_NO_USER = "No User Emb."
ABL_TRAIN_OBS = "Pooled"
ABL_TARGET_OBS = "Target Only"

_ABL_COPL_TAG = {
    ABL_ADAPTED: "w/ CoPL",
    ABL_NO_USER: "w/ CoPL",
    ABL_TRAIN_OBS: "w/o CoPL",
    ABL_TARGET_OBS: "w/o CoPL",
}


def _ablation_xtick_labels(names):
    return [f"{name}\n{_ABL_COPL_TAG[name]}" for name in names]


class CoPLExperiment(BaseExperiment):

    def run(self, out_dir: Path, eval_only: bool = False) -> dict:
        self._out_dir = out_dir
        self._eval_only = eval_only
        self.build()
        if eval_only:
            self.load(out_dir)
            train_metrics = {}
        else:
            with open(out_dir / "cfg.json", "w", encoding="utf-8") as f:
                json.dump(asdict(self.cfg), f, ensure_ascii=False, indent=2)
            train_metrics = self.train(out_dir)
            self.save(out_dir)
        eval_metrics = self.evaluate(out_dir)
        summary = self.make_summary(train_metrics, eval_metrics)
        with open(out_dir / "summary.json", "w") as f:
            json.dump(summary, f, indent=2, ensure_ascii=False)
        return eval_metrics

    def _get_load_path(self, component: str):
        """컴포넌트를 로드할 Path 반환. None이면 학습."""
        if self._eval_only:
            return self._out_dir
        load_ts = getattr(self.cfg, f"load_{component}", None)
        if load_ts is None:
            return None
        return Path("artifacts") / "copl" / load_ts

    def build(self):
        self.device = torch.device(self.cfg.device)
        self._log("=" * 60)
        self._log("[CoPL] Building graph dataset...")
        vae_path = self._get_load_path("vae")
        sim_ckpt_name = f"{self.cfg.similarity_method}.pt"
        if vae_path is not None:
            self._log(f"  [SIM:{self.cfg.similarity_method}] Loading from {vae_path}...")
            sim_builder = build_similarity(self.cfg.similarity_method)
            sim_builder.load(vae_path / sim_ckpt_name, device=self.device)
            self.dataset = CoPLGraphDataset(self.cfg, sim_builder=sim_builder)
        else:
            self.dataset = CoPLGraphDataset(self.cfg)
            self.dataset.sim_builder.save(self._out_dir / sim_ckpt_name)
        self.dataset.to(self.device)
        self.gcf = self._build_gcf()
        self.rm = self._build_rm()
        self.train_obs_rm = self._build_obs_only_rm() if self._train_obs_only_enabled() else None

    def _build_gcf(self):
        ds, cfg = self.dataset, self.cfg
        common = dict(
            n_u=ds.n_users, n_i=ds.n_items, d=cfg.gcf_emb_dim,
            pos_adj_norm=ds.Apos_norm, neg_adj_norm=ds.Aneg_norm,
            dropout=cfg.gcf_dropout, l=cfg.gcf_layers,
            item_item_adj_norm=ds.Aii_norm, item_item_weight=cfg.item_item_weight,
        )
        if cfg.gcf_model == "gcf_gcn":
            from .gcf_gcn import CoPLGCF_PyG
            return CoPLGCF_PyG(**common).to(self.device)

        Z = torch.tensor(self.dataset.Z_train, dtype=torch.float32)  # (n_items, vae_latent_dim)
        if Z.shape[1] != cfg.gcf_emb_dim:
            proj = torch.nn.Linear(Z.shape[1], cfg.gcf_emb_dim, bias=False)
            torch.nn.init.xavier_uniform_(proj.weight)
            with torch.no_grad():
                item_feat_init = proj(Z)
        else:
            item_feat_init = Z

        return CoPLGCF(**common, loss_type=cfg.gcf_loss_type,
                       loss_kwargs=cfg.gcf_loss_kwargs,
                       item_feat_init=item_feat_init,
                       m_i_type=cfg.gcf_m_i_type).to(self.device)

    def _build_rm(self):
        cfg = self.cfg
        common = dict(obs_dim=self.dataset.obs_dim, user_dim=cfg.gcf_emb_dim)
        if cfg.rm_model == "mlp":
            return RewardModel(**common, hidden=cfg.rm_mlp_hidden).to(self.device)
        elif cfg.rm_model == "cnn":
            return CNNRewardModel(**common, hidden=cfg.rm_hidden, mlp_hidden=cfg.rm_mlp_hidden,
                                  kernel_size=cfg.rm_kernel_size, layers=cfg.rm_layers).to(self.device)
        elif cfg.rm_model == "mole_cnn":
            return MoLECNNRewardModel(**common, hidden=cfg.rm_hidden, mlp_hidden=cfg.rm_mlp_hidden,
                                      kernel_size=cfg.rm_kernel_size, layers=cfg.rm_layers,
                                      num_experts=cfg.rm_num_experts, rank=cfg.rm_mole_rank,
                                      tau=cfg.rm_mole_tau).to(self.device)
        elif cfg.rm_model == "preference_transformer":
            return PreferenceTransformerRewardModel(**common, hidden=cfg.rm_hidden, num_heads=cfg.rm_num_heads, num_layers=cfg.rm_layers, max_len=cfg.rm_max_len).to(self.device)
        raise ValueError(f"Unknown rm_model: {cfg.rm_model}")

    def _build_obs_only_rm(self):
        cfg = self.cfg
        common = dict(obs_dim=self.dataset.obs_dim)
        if cfg.rm_model == "mlp":
            return ObsOnlyRewardModel(**common, hidden=cfg.rm_mlp_hidden).to(self.device)
        elif cfg.rm_model == "cnn":
            return ObsOnlyCNNRewardModel(**common, hidden=cfg.rm_hidden, mlp_hidden=cfg.rm_mlp_hidden,
                                         kernel_size=cfg.rm_kernel_size, layers=cfg.rm_layers).to(self.device)
        elif cfg.rm_model == "preference_transformer":
            return ObsOnlyPreferenceTransformerRewardModel(
                **common, hidden=cfg.rm_hidden, num_heads=cfg.rm_num_heads,
                num_layers=cfg.rm_layers, max_len=cfg.rm_max_len).to(self.device)
        raise ValueError(f"Obs-only RM is not implemented for rm_model={cfg.rm_model!r}")

    def _train_obs_only_enabled(self):
        return getattr(self.cfg, "enable_train_obs_only_rm",
                       getattr(self.cfg, "enable_obs_only_rm", False))

    def _ctx_obs_only_enabled(self):
        return getattr(self.cfg, "enable_ctx_obs_only_rm",
                       getattr(self.cfg, "enable_obs_only_rm", False))

    def _train_train_obs_only_rm(self, out_dir: Path, train_loader=None, val_loader=None):
        cfg, ds = self.cfg, self.dataset
        if train_loader is None:
            train_loader = DataLoader(
                RMEdgeDataset(ds.tr_u, ds.tr_i, ds.tr_y, ds.item_series),
                batch_size=cfg.rm_batch_size, shuffle=True, collate_fn=rm_collate)
        if val_loader is None:
            val_loader = DataLoader(
                RMEdgeDataset(ds.va_u, ds.va_i, ds.va_y, ds.item_series),
                batch_size=cfg.rm_batch_size, shuffle=False, collate_fn=rm_collate)

        obs_rm_trainer = CoPLRMTrainer(self.train_obs_rm, {
            'device': cfg.device, 'rm_lr': cfg.rm_lr,
            'rm_weight_decay': cfg.rm_weight_decay, 'rm_lambda_reg': cfg.rm_lambda_reg,
            'rm_epochs': cfg.rm_epochs, 'use_pos_weight': cfg.use_pos_weight,
        }, log_dir=out_dir, checkpoint_name="best_obs_rm.pt")
        return obs_rm_trainer.train(train_loader, val_loader, None, ds.tr_y, verbose=cfg.verbose)

    def _predict_no_user_branch(self, obs):
        if not hasattr(self.rm, "forward_no_user"):
            return None
        with torch.no_grad():
            return torch.sigmoid(self.rm.forward_no_user(obs)).cpu().numpy()

    def _split_ctx_obs_only(self, y_ctx):
        cfg = self.cfg
        y_ctx = np.asarray(y_ctx, dtype=np.int64)
        n_ctx = len(y_ctx)
        if n_ctx < 2:
            return np.arange(n_ctx), np.array([], dtype=np.int64), "no_val_too_small"

        val_size = float(getattr(cfg, "val_size", 0.1))
        if val_size <= 0.0:
            return np.arange(n_ctx), np.array([], dtype=np.int64), "no_val_disabled"

        n_val = int(np.ceil(n_ctx * min(max(val_size, 0.0), 0.9)))
        n_val = min(max(1, n_val), n_ctx - 1)
        indices = np.arange(n_ctx)

        stratify = None
        split_mode = "random"
        classes, counts = np.unique(y_ctx, return_counts=True)
        if len(classes) == 2 and counts.min() >= 2 and n_val >= 2 and (n_ctx - n_val) >= 2:
            stratify = y_ctx
            split_mode = "stratified"

        try:
            tr_idx, va_idx = train_test_split(
                indices, test_size=n_val, random_state=getattr(cfg, "seed", 42), stratify=stratify)
        except ValueError:
            tr_idx, va_idx = train_test_split(
                indices, test_size=n_val, random_state=getattr(cfg, "seed", 42), stratify=None)
            split_mode = "random_fallback"

        return tr_idx.astype(np.int64), va_idx.astype(np.int64), split_mode

    def _fit_ctx_obs_only_rm(self, X_ctx, y_ctx, X_eval):
        cfg = self.cfg
        model = self._build_obs_only_rm()
        model.train()

        y_ctx = np.asarray(y_ctx, dtype=np.int64)
        tr_idx, va_idx, split_mode = self._split_ctx_obs_only(y_ctx)
        X_tr, y_tr = X_ctx[tr_idx], y_ctx[tr_idx]
        X_va, y_va = X_ctx[va_idx], y_ctx[va_idx]

        train_loader = DataLoader(
            RMEdgeDataset(np.zeros(len(X_tr), dtype=np.int64), np.arange(len(X_tr)), y_tr, X_tr),
            batch_size=min(getattr(cfg, "rm_batch_size", 256), max(1, len(X_tr))),
            shuffle=True,
            collate_fn=rm_collate,
        )
        val_loader = None
        if len(X_va) > 0:
            val_loader = DataLoader(
                RMEdgeDataset(np.zeros(len(X_va), dtype=np.int64), np.arange(len(X_va)), y_va, X_va),
                batch_size=min(getattr(cfg, "rm_batch_size", 256), len(X_va)),
                shuffle=False,
                collate_fn=rm_collate,
            )
        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=getattr(cfg, "rm_lr", 1e-3),
            weight_decay=getattr(cfg, "rm_weight_decay", 0.0),
        )

        pos_weight = None
        if getattr(cfg, "use_pos_weight", True):
            pos_cnt = int(np.sum(y_tr))
            neg_cnt = int(len(y_tr) - pos_cnt)
            if pos_cnt > 0 and neg_cnt > 0:
                pos_weight = torch.tensor([neg_cnt / pos_cnt], dtype=torch.float32, device=self.device)

        epochs = int(getattr(cfg, "rm_epochs", 100))
        patience = int(getattr(cfg, "ctx_obs_only_patience", max(1, epochs // 5)))
        last_loss = float("nan")
        best_score = -float("inf")
        best_state = None
        best_epoch = -1
        best_val_loss = float("nan")
        best_val_auc = float("nan")
        bad_epochs = 0
        epochs_run = 0
        for epoch in range(max(1, epochs)):
            epochs_run = epoch + 1
            for _, obs_b, y_b in train_loader:
                obs_b = obs_b.to(self.device)
                y_b = y_b.float().to(self.device)
                logits = model(obs_b)
                loss = torch.nn.functional.binary_cross_entropy_with_logits(
                    logits, y_b, pos_weight=pos_weight)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                last_loss = float(loss.item())

            if val_loader is None:
                continue

            model.eval()
            val_logits, val_labels = [], []
            val_loss_total, n_val_seen = 0.0, 0
            with torch.no_grad():
                for _, obs_b, y_b in val_loader:
                    obs_b = obs_b.to(self.device)
                    y_b_dev = y_b.float().to(self.device)
                    logits = model(obs_b)
                    val_loss = torch.nn.functional.binary_cross_entropy_with_logits(logits, y_b_dev)
                    val_loss_total += float(val_loss.item()) * len(y_b)
                    n_val_seen += len(y_b)
                    val_logits.append(logits.cpu())
                    val_labels.append(y_b)
            model.train()

            val_probs = torch.sigmoid(torch.cat(val_logits)).numpy()
            val_y = torch.cat(val_labels).numpy().astype(np.int64)
            val_loss_mean = val_loss_total / max(1, n_val_seen)
            val_auc = roc_auc_score(val_y, val_probs) if len(np.unique(val_y)) > 1 else float("nan")
            score = val_auc if not np.isnan(val_auc) else -val_loss_mean

            if score > best_score:
                best_score = score
                best_epoch = epoch + 1
                best_val_loss = val_loss_mean
                best_val_auc = val_auc
                best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
                bad_epochs = 0
            else:
                bad_epochs += 1
                if patience > 0 and bad_epochs >= patience:
                    break

        if best_state is not None:
            model.load_state_dict({k: v.to(self.device) for k, v in best_state.items()})

        model.eval()
        eval_obs = torch.tensor(X_eval, dtype=torch.float32, device=self.device)
        with torch.no_grad():
            probs = torch.sigmoid(model(eval_obs)).cpu().numpy()
        info = {
            "train_n": int(len(X_tr)),
            "val_n": int(len(X_va)),
            "split": split_mode,
            "epochs_run": int(epochs_run),
            "best_epoch": int(best_epoch if best_epoch > 0 else epochs_run),
            "train_loss_last": float(last_loss),
            "val_loss": float(best_val_loss),
            "val_auroc": float(best_val_auc),
        }
        return probs, info

    def train(self, out_dir: Path) -> dict:
        cfg, ds = self.cfg, self.dataset

        gcf_path = self._get_load_path("gcf")
        if gcf_path is None:
            self._log("\n[1] Training GCF...")
            gcf_trainer = CoPLGCFTrainer(self.gcf, {
                'device': cfg.device, 'gcf_lr': cfg.gcf_lr,
                'gcf_weight_decay': cfg.gcf_weight_decay, 'gcf_lambda_reg': cfg.gcf_lambda_reg,
                'gcf_epochs': cfg.gcf_epochs, 'use_pos_weight': cfg.use_pos_weight,
            }, log_dir=out_dir)
            gcf_best_auc, _, E_u, E_i, gcf_metrics = gcf_trainer.train(
                ds.tr_u, ds.tr_i, ds.tr_y, ds.va_u, ds.va_i, ds.va_y, verbose=cfg.verbose)
            self.E_u = E_u.to(self.device)
            self.E_i = E_i
            self._log(f"  GCF Best Val AUC: {gcf_best_auc:.4f}")
        else:
            self._log(f"\n[1] Loading GCF from {gcf_path}...")
            self.gcf.load_state_dict(torch.load(gcf_path / "best_gcf.pt", map_location=self.device, weights_only=True))
            self.gcf.eval()
            with torch.no_grad():
                E_u, E_i = self.gcf.encode_graph(test=True)
            self.E_u = E_u.to(self.device)
            self.E_i = E_i
            gcf_best_auc = float("nan")
            gcf_metrics = {}

        train_loader = DataLoader(
            RMEdgeDataset(ds.tr_u, ds.tr_i, ds.tr_y, ds.item_series),
            batch_size=cfg.rm_batch_size, shuffle=True, collate_fn=rm_collate)
        val_loader = DataLoader(
            RMEdgeDataset(ds.va_u, ds.va_i, ds.va_y, ds.item_series),
            batch_size=cfg.rm_batch_size, shuffle=False, collate_fn=rm_collate)

        rm_path = self._get_load_path("rm")
        if rm_path is None:
            self._log("\n[2] Training Reward Model...")
            rm_trainer = CoPLRMTrainer(self.rm, {
                'device': cfg.device, 'rm_lr': cfg.rm_lr,
                'rm_weight_decay': cfg.rm_weight_decay, 'rm_lambda_reg': cfg.rm_lambda_reg,
                'rm_epochs': cfg.rm_epochs, 'use_pos_weight': cfg.use_pos_weight,
            }, log_dir=out_dir)
            rm_best_auc, rm_metrics = rm_trainer.train(train_loader, val_loader, self.E_u, ds.tr_y, verbose=cfg.verbose)
            self._log(f"  RM Best Val AUC: {rm_best_auc:.4f}")
        else:
            self._log(f"\n[2] Loading Reward Model from {rm_path}...")
            self.rm.load_state_dict(torch.load(rm_path / "best_rm.pt", map_location=self.device, weights_only=True))
            rm_best_auc = float("nan")
            rm_metrics = {}

        train_obs_rm_best_auc = float("nan")
        train_obs_rm_metrics = {}
        if self.train_obs_rm is not None:
            self._log(f"\n[2b] Training {ABL_TRAIN_OBS}...")
            train_obs_rm_best_auc, train_obs_rm_metrics = self._train_train_obs_only_rm(
                out_dir, train_loader, val_loader)
            self._log(f"  {ABL_TRAIN_OBS} Best Val AUC: {train_obs_rm_best_auc:.4f}")

        combined = {}
        for k, v in gcf_metrics.items():
            prefix, name = k.split("/", 1)
            combined[f"{prefix}/gcf_{name}"] = v
        for k, v in rm_metrics.items():
            prefix, name = k.split("/", 1)
            combined[f"{prefix}/rm_{name}"] = v
        for k, v in train_obs_rm_metrics.items():
            prefix, name = k.split("/", 1)
            combined[f"{prefix}/train_obs_rm_{name}"] = v
        if combined:
            plot_training_curves(combined, out_dir / "plots" / "training_curves.png", title="CoPL Training")

        return {"gcf_val_auroc": gcf_best_auc, "rm_val_auroc": rm_best_auc,
                "train_obs_rm_val_auroc": train_obs_rm_best_auc}

    def evaluate(self, out_dir: Path) -> dict:
        cfg, ds = self.cfg, self.dataset
        self._log(f"\n[3] Test-time evaluation on {cfg.test_driver}...")
        X_test, y_test = ds.load_test_driver(cfg.test_driver)

        self.rm.eval()
        all_metrics = {}
        neigh_idx_last, neigh_w_last = None, None
        wu_history, ctx_sizes_wu, e_u_final = [], [], None

        split_idx = len(X_test) // 2
        if split_idx >= 1 and len(X_test) - split_idx >= 1:
            holdout_X = X_test[split_idx:]
            holdout_y = y_test[split_idx:]
            
            if len(np.unique(holdout_y)) < 2:
                self._log(f"  [Warning] {cfg.test_driver} test set lacks both classes. Skipping seq AUROC.")
            else:
                ctx_sizes, test_aurocs = [], []
                final_probs = None
                best_probs, best_auroc_val = None, -1.0
                best_e_u_t, best_w_u, best_neigh_idx, best_neigh_w = None, None, None, None
                holdout_obs = torch.tensor(holdout_X, dtype=torch.float32).to(self.device)
                no_user_branch_probs = self._predict_no_user_branch(holdout_obs)
                if no_user_branch_probs is not None:
                    no_user_metrics = evaluate_predictions(
                        holdout_y, no_user_branch_probs, out_dir / "plots" / "wo_user_emb",
                        cfg.test_driver, title=f"{ABL_NO_USER} - {cfg.test_driver}")
                    all_metrics[f"wo_user_emb/{cfg.test_driver}"] = no_user_metrics
                    self._log(f"  {ABL_NO_USER} AUROC: {no_user_metrics['auroc']:.4f}  "
                              f"AUPRC: {no_user_metrics['auprc']:.4f}  "
                              f"Brier: {no_user_metrics['brier']:.4f}")

                train_obs_only_probs = None
                if self.train_obs_rm is not None:
                    self.train_obs_rm.eval()
                    with torch.no_grad():
                        train_obs_only_probs = torch.sigmoid(self.train_obs_rm(holdout_obs)).cpu().numpy()
                    train_obs_metrics = evaluate_predictions(
                        holdout_y, train_obs_only_probs, out_dir / "plots" / "train_user_pooled",
                        cfg.test_driver, title=f"{ABL_TRAIN_OBS} - {cfg.test_driver}")
                    all_metrics[f"train_user_pooled/{cfg.test_driver}"] = train_obs_metrics
                    self._log(f"  {ABL_TRAIN_OBS} AUROC: {train_obs_metrics['auroc']:.4f}  "
                              f"AUPRC: {train_obs_metrics['auprc']:.4f}  "
                              f"Brier: {train_obs_metrics['brier']:.4f}")

                target_pcts = [0.1, 0.2, 0.3, 0.4, 0.5]
                snapshot_steps = {max(1, int(len(X_test) * p)): int(p * 100) for p in target_pcts}
                snapshot_steps = {k: v for k, v in snapshot_steps.items() if k <= split_idx}

                for t in range(1, split_idx + 1):
                    _, neigh_idx_ctx, neigh_w_ctx = ds.attach_test_items(
                        X_test[:t], self.E_i.cpu(), topk=cfg.adapt_topk, device=self.device)
                    e_u_t, w_u = ds.adapt_test_user(
                        y_test[:t], neigh_idx_ctx, neigh_w_ctx, self.E_u, device=self.device)

                    wu_history.append(w_u)
                    ctx_sizes_wu.append(t)
                    e_u_final = e_u_t

                    e_u_t_expanded = e_u_t.unsqueeze(0).expand(len(holdout_X), -1)
                    with torch.no_grad():
                        probs = torch.sigmoid(self.rm(e_u_t_expanded, holdout_obs)).cpu().numpy()

                    auroc = roc_auc_score(holdout_y, probs)
                    ctx_sizes.append(t)
                    test_aurocs.append(auroc)
                    final_probs = probs
                    if auroc > best_auroc_val:
                        best_auroc_val, best_probs = auroc, probs
                        best_e_u_t, best_w_u = e_u_t, w_u
                        best_neigh_idx, best_neigh_w = neigh_idx_ctx, neigh_w_ctx
                    neigh_idx_last, neigh_w_last = neigh_idx_ctx, neigh_w_ctx

                    if t in snapshot_steps:
                        pct = snapshot_steps[t]
                        self._log(f"  [Context {pct:>3}%] AUROC={auroc:.4f}")
                        snap_dir = out_dir / "plots" / "snapshots" / f"context_{pct}pct"
                        snap_dir.mkdir(parents=True, exist_ok=True)

                        evaluate_predictions(holdout_y, probs, snap_dir, "metrics",
                                             title=f"CoPL - {cfg.test_driver} (Context {pct}%)")

                        fig, ax = plt.subplots(figsize=(8, 4))
                        ax.bar(cfg.train_driver_names, w_u, color="mediumseagreen")
                        ax.set_title(f"User Attention (w_u) - Context {pct}%")
                        ax.set_ylabel("Weight")
                        ax.set_ylim(0, 1.0)
                        ax.grid(axis='y', alpha=0.3)
                        fig.tight_layout()
                        fig.savefig(snap_dir / "user_attention.png", dpi=100)
                        plt.close(fig)

                        plot_test_item_bridge(neigh_idx_ctx, neigh_w_ctx, ds.item_owner_uid, ds.train_drivers,
                                              snap_dir / "item_bridge.png")

                        abl_names = [ABL_ADAPTED]
                        abl_auroc_vals = [auroc]
                        if no_user_branch_probs is not None:
                            abl_names.append(ABL_NO_USER)
                            abl_auroc_vals.append(roc_auc_score(holdout_y, no_user_branch_probs))
                        if train_obs_only_probs is not None:
                            abl_names.append(ABL_TRAIN_OBS)
                            abl_auroc_vals.append(roc_auc_score(holdout_y, train_obs_only_probs))

                        S = STYLE["diag"]
                        fig, ax = plt.subplots(figsize=(9, 4.8))
                        colors = ["steelblue", "mediumpurple", "seagreen", "salmon"]
                        x = np.arange(len(abl_names))
                        bars = ax.bar(x, abl_auroc_vals, color=colors[:len(abl_names)])
                        for bar, val in zip(bars, abl_auroc_vals):
                            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.005,
                                    f"{val:.4f}", ha="center", va="bottom", fontsize=S["annot_fs"]+2)
                        ax.set_title(f"Model Ablation - Context {pct}%", fontsize=S["title_fs"])
                        ax.set_ylabel("AUROC", fontsize=S["label_fs"])
                        ax.set_xticks(x, _ablation_xtick_labels(abl_names))
                        ax.tick_params(axis="x", labelsize=S["tick_fs"] + 3, rotation=0)
                        ax.tick_params(axis="y", labelsize=S["tick_fs"])
                        for label in ax.get_xticklabels():
                            label.set_ha("center")
                            label.set_multialignment("center")
                        ax.set_ylim(0, 1.05)
                        ax.grid(axis="y", alpha=0.3)
                        fig.tight_layout()
                        fig.subplots_adjust(bottom=0.24)
                        fig.savefig(snap_dir / "user_emb_ablation.png", dpi=100)
                        plt.close(fig)

                if final_probs is not None:
                    plot_sequential_auroc(ctx_sizes, test_aurocs, out_dir / "plots", cfg.test_driver)
                    best_ctx = ctx_sizes[test_aurocs.index(best_auroc_val)]
                    best_pct = round(best_ctx / len(X_test) * 100)
                    ctx_obs_only_probs = None
                    if self._ctx_obs_only_enabled():
                        ctx_obs_only_probs, ctx_obs_info = self._fit_ctx_obs_only_rm(
                            X_test[:best_ctx], y_test[:best_ctx], holdout_X)
                        ctx_obs_metrics = evaluate_predictions(
                            holdout_y, ctx_obs_only_probs, out_dir / "plots" / "target_user_only",
                            cfg.test_driver,
                            title=f"{ABL_TARGET_OBS} - {cfg.test_driver} (ctx={best_pct}%)")
                        ctx_obs_metrics.update(ctx_obs_info)
                        all_metrics[f"target_user_only/{cfg.test_driver}"] = ctx_obs_metrics
                        val_auc = ctx_obs_info["val_auroc"]
                        val_auc_text = f"{val_auc:.4f}" if not np.isnan(val_auc) else "N/A"
                        self._log(f"  {ABL_TARGET_OBS}: ctx={best_ctx}  "
                                  f"train={ctx_obs_info['train_n']}  val={ctx_obs_info['val_n']}  "
                                  f"split={ctx_obs_info['split']}  val_auc={val_auc_text}  "
                                  f"val_loss={ctx_obs_info['val_loss']:.4f}  "
                                  f"AUROC={ctx_obs_metrics['auroc']:.4f}  "
                                  f"AUPRC={ctx_obs_metrics['auprc']:.4f}  "
                                  f"Brier={ctx_obs_metrics['brier']:.4f}")
                    m = evaluate_predictions(holdout_y, best_probs, out_dir / "plots", cfg.test_driver,
                                              title=f"CoPL - {cfg.test_driver} (best ctx={best_pct}%)")
                    all_metrics[f"test/{cfg.test_driver}"] = m
                    self._log(f"  Test AUROC: {m['auroc']:.4f}  AUPRC: {m['auprc']:.4f}  Brier: {m['brier']:.4f}")

                    # best 스냅샷
                    snap_dir = out_dir / "plots" / "snapshots" / "context_best"
                    snap_dir = out_dir / "plots" / "snapshots" / "context_best"
                    snap_dir.mkdir(parents=True, exist_ok=True)
                    evaluate_predictions(holdout_y, best_probs, snap_dir, "metrics",
                                         title=f"CoPL - {cfg.test_driver} (best ctx={best_pct}%)")
                    S = STYLE["diag"]
                    fig, ax = plt.subplots(figsize=(8, 4))
                    ax.bar(cfg.train_driver_names, best_w_u, color="mediumseagreen")
                    ax.set_title(f"User Attention (w_u) - Best ctx={best_pct}%", fontsize=S["title_fs"])
                    ax.set_ylabel("Weight", fontsize=S["label_fs"])
                    ax.tick_params(labelsize=S["tick_fs"])
                    ax.set_ylim(0, 1.0)
                    ax.grid(axis='y', alpha=0.3)
                    fig.tight_layout()
                    fig.savefig(snap_dir / "user_attention.png", dpi=100)
                    plt.close(fig)
                    plot_test_item_bridge(best_neigh_idx, best_neigh_w, ds.item_owner_uid, ds.train_drivers,
                                          snap_dir / "item_bridge.png")
                    abl_names = [ABL_ADAPTED]
                    abl_auroc_vals = [best_auroc_val]
                    if no_user_branch_probs is not None:
                        abl_names.append(ABL_NO_USER)
                        abl_auroc_vals.append(roc_auc_score(holdout_y, no_user_branch_probs))
                    if ctx_obs_only_probs is not None:
                        abl_names.append(ABL_TARGET_OBS)
                        abl_auroc_vals.append(roc_auc_score(holdout_y, ctx_obs_only_probs))
                    if train_obs_only_probs is not None:
                        abl_names.append(ABL_TRAIN_OBS)
                        abl_auroc_vals.append(roc_auc_score(holdout_y, train_obs_only_probs))
                    fig, ax = plt.subplots(figsize=(9, 4.8))
                    colors = ["steelblue", "mediumpurple", "seagreen", "salmon"]
                    x = np.arange(len(abl_names))
                    bars = ax.bar(x, abl_auroc_vals, color=colors[:len(abl_names)])
                    for bar, val in zip(bars, abl_auroc_vals):
                        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.005,
                                f"{val:.4f}", ha="center", va="bottom", fontsize=S["annot_fs"]+2)
                    ax.set_title(f"Model Ablation - Best ctx={best_pct}%", fontsize=S["title_fs"])
                    ax.set_ylabel("AUROC", fontsize=S["label_fs"])
                    ax.set_xticks(x, _ablation_xtick_labels(abl_names))
                    ax.tick_params(axis="x", labelsize=S["tick_fs"] + 3, rotation=0)
                    ax.tick_params(axis="y", labelsize=S["tick_fs"])
                    for label in ax.get_xticklabels():
                        label.set_ha("center")
                        label.set_multialignment("center")
                    ax.set_ylim(0, 1.05)
                    ax.grid(axis="y", alpha=0.3)
                    fig.tight_layout()
                    fig.subplots_adjust(bottom=0.24)
                    fig.savefig(snap_dir / "user_emb_ablation.png", dpi=100)
                    plt.close(fig)

                    self._log("\n  [Ablation] Model comparison (best ctx):")
                    ablation = {}
                    for abl_name, abl_auroc in zip(abl_names, abl_auroc_vals):
                        ablation[abl_name] = round(abl_auroc, 4)
                        self._log(f"    {abl_name:>10}: AUROC={abl_auroc:.4f}")
                    all_metrics["ablation/user_emb"] = ablation

        plots_dir = out_dir / "plots"
        if neigh_idx_last is not None:
            plot_test_item_bridge(neigh_idx_last, neigh_w_last, ds.item_owner_uid, ds.train_drivers,
                                  plots_dir / "bridge.png")

        self._log("\n[4] Evaluating training drivers...")
        for uid, uname in enumerate(cfg.train_driver_names):
            u_tr = ds.tr_u == uid
            u_va = ds.va_u == uid
            u_iids = np.concatenate([ds.tr_i[u_tr], ds.va_i[u_va]])
            u_labels = np.concatenate([ds.tr_y[u_tr], ds.va_y[u_va]])
            if len(u_iids) == 0:
                continue
            obs_u = torch.tensor(ds.item_series[u_iids], dtype=torch.float32).to(self.device)
            u_emb = self.E_u[uid].unsqueeze(0).expand(len(u_iids), -1)
            with torch.no_grad():
                u_probs = torch.sigmoid(self.rm(u_emb, obs_u)).cpu().numpy()
            m = evaluate_predictions(u_labels, u_probs, plots_dir / "train", uname,
                                      title=f"CoPL - {uname} (train)")
            all_metrics[f"train/{uname}"] = m
            self._log(f"  {uname}: AUROC={m['auroc']:.4f}  AUPRC={m['auprc']:.4f}  Brier={m['brier']:.4f}")

        item_labels = np.zeros(ds.n_items, dtype=np.int64)
        for uid, (item_ids, y) in ds.per_user_items.items():
            item_labels[item_ids] = y

        ds.sim_builder.visualize(plots_dir / "similarity", ds.item_series, ds.item_owner_uid,
                                 cfg.train_driver_names, list(cfg.features), item_labels)
        E_i_test = None
        if neigh_idx_last is not None:
            E_i_cpu = self.E_i.detach().cpu().numpy()
            E_i_test = torch.tensor(np.stack([
                (neigh_w_last[i][:, None] * E_i_cpu[neigh_idx_last[i]]).sum(axis=0)
                for i in range(neigh_idx_last.shape[0])
            ]))
        plot_item_embeddings(self.E_i, ds.item_owner_uid,
                             cfg.train_driver_names, plots_dir / "embeddings",
                             E_i_test=E_i_test, test_driver_name=cfg.test_driver)
        plot_user_embeddings(self.E_u, cfg.train_driver_names,
                             e_u_final, cfg.test_driver, plots_dir / "embeddings")
        plot_rm_distributions(self.rm, self.E_u, ds.item_series, ds.item_owner_uid,
                              item_labels, cfg.train_driver_names, self.device, plots_dir / "reward_model")
        plot_wu_evolution(wu_history, ctx_sizes_wu, cfg.train_driver_names,
                          plots_dir / "wu_evolution.png")

        save_metrics_txt(all_metrics, out_dir / "metrics.txt")
        return all_metrics

    def save(self, out_dir: Path) -> None:
        pass  # CoPLGCFTrainer, CoPLRMTrainer가 best_gcf.pt, best_rm.pt 저장

    def load(self, out_dir: Path) -> None:
        self.gcf.load_state_dict(torch.load(out_dir / "best_gcf.pt", map_location=self.device, weights_only=True))
        self.gcf.eval()
        with torch.no_grad():
            self.E_u, self.E_i = self.gcf.encode_graph(test=True)
        self.E_u = self.E_u.to(self.device)
        self.rm.load_state_dict(torch.load(out_dir / "best_rm.pt", map_location=self.device, weights_only=True))
        if self.train_obs_rm is not None:
            obs_ckpt = out_dir / "best_obs_rm.pt"
            if obs_ckpt.exists():
                self.train_obs_rm.load_state_dict(
                    torch.load(obs_ckpt, map_location=self.device, weights_only=True))
            elif getattr(self.cfg, "train_obs_only_if_missing", True):
                self._log(f"\n[Eval-only] {ABL_TRAIN_OBS} checkpoint missing; training baseline...")
                obs_best_auc, _ = self._train_train_obs_only_rm(out_dir)
                self._log(f"  {ABL_TRAIN_OBS} Best Val AUC: {obs_best_auc:.4f}")
            else:
                self._log(f"  [Warning] {ABL_TRAIN_OBS} checkpoint not found at {obs_ckpt}; skipping.")
                self.train_obs_rm = None

    def make_summary(self, train_metrics: dict, eval_metrics: dict) -> dict:
        s = super().make_summary(train_metrics, eval_metrics)
        s["test_driver"] = self.cfg.test_driver
        s["similarity_method"] = self.cfg.similarity_method
        s["aii_meta"] = self.dataset.Aii_meta
        return s
